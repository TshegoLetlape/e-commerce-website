export enum AppRoutePath {
  Checkout = '/checkout',
}
