export enum CheckoutRoutePath {
  Delivery = '/delivery',
  Payment = '/payment',
  Confirmation = '/confirmation',
}
