import { CreditCardFormValues } from './credit-card-form-values.interface';

export const initialCreditCardValues: CreditCardFormValues = {
  cardNumber: '',
  expiryDate: '',
  securityCode: '',
};
