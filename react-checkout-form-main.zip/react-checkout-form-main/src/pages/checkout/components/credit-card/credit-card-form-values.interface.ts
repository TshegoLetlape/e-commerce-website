export interface CreditCardFormValues {
  cardNumber: string;
  expiryDate: string;
  securityCode: string;
}
