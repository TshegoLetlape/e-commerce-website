export interface SignupFormValues {
  guestCheckout: boolean;
  email: string;
  password: string;
  confirmPassword: string;
}
