export enum ShippingMethod {
  free = 'free',
  express = 'express',
  nextDay = 'nextDay',
}
