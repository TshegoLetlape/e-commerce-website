import { CheckoutState } from '../pages/checkout/store/checkout-state.interface';

export interface RootState {
  checkout: CheckoutState;
}
